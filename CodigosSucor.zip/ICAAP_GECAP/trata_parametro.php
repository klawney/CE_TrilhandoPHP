<?php
session_start();
	include("funcoes.php");
// ==================================================================================================================================================

		$StrParXML="";
		//-------------------
		foreach ($_POST as $reg=>$dado){
			//echo "$reg - $dado<br>";
			if(!empty($dado)) {
				// ==
				if(substr($reg, 0, 3)=='div') {
					echo '$dividendos[';
					echo substr($reg, 3, 1).'][';
					echo substr($reg, 5, 5).']='.$dado.'<br>';
					///
					$dividendos[substr($reg, 3, 1)][substr($reg, 5, 5)]=$dado;
				}	
				// ==
				if(substr($reg, 0, 3)=='cap') {
					echo '$capitalizacoes[';
					echo substr($reg, 3, 1).'][';
					echo substr($reg, 5, 5).']='.$dado.'<br>';
					///
					$capitalizacoes[substr($reg, 3, 1)][substr($reg, 5, 5)]=$dado;
				}	
				// ==
				if(substr($reg, 0, 3)=='IHC') {
					//echo substr($reg, 5, 4);			
							
					//echo "--$dado <br>";
					if(substr($reg, 5, 4)=='Vige') { //Vigetente
						//echo "vigente $dado";					
						//echo $reg;					
						echo '$IHCD[';
						echo substr($reg, 9, 6).'][';
						echo substr($reg, 16, 5).']='.$dado.'<br>';
						///
						$IHCDs[substr($reg, 9, 6)][substr($reg,16, 5)]=$dado;				
					}
					if(substr($reg, 5, 4)=='Novo'){ // Novo
						//echo "Novo $dado";
						echo '$IHCD[';
						echo substr($reg, 9, 1).'][';
						echo substr($reg, 11, 5).']='.$dado.'<br>';
						///
						$IHCDs[substr($reg, 9, 1)][substr($reg, 11, 5)]=$dado;				
				
					}
	
				}	
				// ==
				if(substr($reg, 0, 3)=='IDS') {
					//echo substr($reg, 10, 1);			
							
					//echo "--$dado <br>";
					if(substr($reg, 4, 4)=='Vige') { //Vigetente
						//echo "vigente $dado";					
						//echo $reg;					
						echo '$IDS[';
						echo substr($reg, 9, 7).'][';
						echo substr($reg, 17, 5).']='.$dado.'<br>';
						///
						$IDSes[substr($reg, 9, 7)][substr($reg,17, 5)]=$dado;				
					}
					if(substr($reg, 4, 4)=='Novo'){ // Novo
						//echo $reg;				
						//echo "Novo $dado";
						echo '$IDS[';
						echo substr($reg, 8, 1).'][';
						echo substr($reg, 10, 5).']='.$dado.'<br>';
						///
						$IDSes[substr($reg, 8, 1)][substr($reg, 10, 5)]=$dado;				
				
					}
	
				}	
			}
		//-- FIM POST
		}
	echo '=======================================================================';
	?>
			<br>	
	<?php 
//---------------------------------------Criando XML --------------		
		$StXa='<';
		$StXf='>';
		if(isset($dividendos)) {		
			foreach ($dividendos as $i=>$dv){
				$StrParXML.=$StXa."DIVIDENDO";	
				//echo $dv;
				foreach ($dv as $ind=>$valor){
					if($ind=='datab'){
						$StrParXML.=' DATABASE="'.$valor.'"';
					}
					if($ind=='valor'){
						$StrParXML.=' VALOR="'.$valor.'"';
					}						
				}			
				$StrParXML.="/$StXf";
			}
		}
	//--------		
		if(isset($capitalizacoes)) {	
			foreach ($capitalizacoes as $i=>$dv){
				$StrParXML.=$StXa."CAPITALIZACAO";	
				//echo $dv;
				foreach ($dv as $ind=>$valor){
					if($ind=='datab'){
						$StrParXML.=' DATABASE="'.$valor.'"';
					}
					if($ind=='valor'){
						$StrParXML.=' VALOR="'.$valor.'"';
					}						
				}			
			$StrParXML.="/$StXf";
		}
	}
	//--------		
		if(isset($IHCDs)) {	
			foreach ($IHCDs as $i=>$dv){
				// Se data estiver vazio nçã foi alterado
				if(!empty($dv['datab'])) {
					// Se nçã tem Nco significa que é um cont Novo
					!empty($dv['NCto'])? $StrParXML.=$StXa."IHCD_ADEQ" : $StrParXML.=$StXa."IHCD_NOVO";
					foreach ($dv as $ind=>$valor){
						if($ind=='NCto'){
							$StrParXML.=' CONTRATO="'.$valor.'"';
						}	
						if($ind=='datab'){
							$StrParXML.=' DATABASE="'.$valor.'"';
						}
						if($ind=='valor'){
							$StrParXML.=' VALOR="'.$valor.'"';
						}		
						if($ind=='Enq'){
							$StrParXML.=' ENQUADRAMENTO="'.$valor.'"';
						}														
					}
				$StrParXML.="/$StXf";
			}			
		}
	}
	//--------		
		if(isset($IDSes)) {	
			foreach ($IDSes as $i=>$dv){
				//echo "$i";
				// Se data estiver vazio nçã foi alterado $dv
				if(!empty($dv['datab'])) {
					// Se nçã tem Nco significa que é um cont Novo
					!empty($dv['NCto'])? $StrParXML.=$StXa."IDS_ADEQ" : $StrParXML.=$StXa."IDS_NOVO";
					foreach ($dv as $ind=>$valor){
						if($ind=='NCto'){
							$StrParXML.=' CONTRATO="'.$valor.'"';
						}	
						if($ind=='datab'){
							$StrParXML.=' DATABASE="'.$valor.'"';
						}
						if($ind=='valor'){
							$StrParXML.=' VALOR="'.$valor.'"';
						}		
						if($ind=='Enq'){
							$StrParXML.=' ENQUADRAMENTO="'.$valor.'"';
						}													
						if($ind=='prazo'){
							$StrParXML.=' PRAZO="'.$valor.'"';
						}		
					}
				$StrParXML.="/$StXf";
			}			
		}
	}		
// ----------------------------	
//$_SESSION['id_simulacao']=geraIdXML($StrParXML);
echo str_replace("<","<br>", str_replace(">", "",@$StrParXML ));

	if($StrParXML=="") {
		$_SESSION['id_simulacao']=0;
	}
	else {
		echo $StrParXML;

		$_SESSION['id_simulacao']=geraIdXML($StrParXML);
		//$_SESSION['id_simulacao']=100;

		}
	echo $_SESSION['id_simulacao'];
	header("Location: index.php#aba-2"); 
?>