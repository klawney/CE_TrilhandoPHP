<!--------1---------2---------3---------4---------5---------6---------7---------8---------9---------0
===================================== TITULO  ============================================
<!-- Pagina  -->
<!--  -------------------------------------------------------------------------------------
===================================== REQUISITOS FUNCIONAIS ==============================
* Gerais:
- ???? 

* Especificos:
- ????;
------------------------------------------------------------------------------------------
====================================== RESPONSAVEIS ======================================
- Sob Resposabilidade de SUCOR02 - Integra??o de Riscos
	- C073149 =  Claudinei da Costa 	R=5197
------------------------------------------------------------------------------------------
============================== HISTORICO DE REVISOES ===================================== 
	*===============*==============*=========================================*================*
	|   Vers?o    	 |      Data 	 |         Altera??o								 |  Respons?vel	|
	*===============*==============*=========================================*================*
   |   Inicial   	 |  06/05/2013	 |				NA 									 |   	C073149 		|
   |-----------------------------------------------------------------------------------------|
	|	 V-02			 |  09/05/2013	 | utiliza??o de JQuery Abas               |		C073149		|
	*========================================================================*================*	
------------------------------------------------------------------------------------------
=========================  INICIO C?DIGO  ==============================================-->

<!--
----------------------------------------------------------------------------------------
-->
<?php
//session_start([]);
	include("funcoes.php");
	// --- Vari?veis de Uso diversos---
	$tm="6%";
	$NAOSIMULADO=0; 
	$novasimulacao=false;
	$aMeses= array('JANEIRO', 'FEVEREIRO', 'MARCO', 'ABRIL', 'MAIO', 'JUNHO', 'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO');
	// verifica se ja existe um id de simula??o, sen?o gera um para ser usado - Vincular ao bot?o solicita simula??o	
	if(!isset($_SESSION['id_simulacao'])) { //|| $novasimulacao
		$_SESSION['id_simulacao']=$NAOSIMULADO;
		//$_SESSION['id_simulacao']=geraId();
	}
	$id_simulacao=$_SESSION['id_simulacao'];
	//--------------- Verifica se usu?rio escolheu ANO especifico -------------------
	isset($_REQUEST['Ano'])? @$AnoRef=$_REQUEST['Ano']:@$AnoRef='2013';
	// ===============================================================================================================================================
	// CONSULTA ABA PATRIM?NIO DE REFER?NCIA
		$stSqlREF="
		SELECT 
      DE_CAPITAL, JANEIRO, FEVEREIRO, MARCO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO
		FROM
      SITE_SIMULADOR.DBO.BASVWXXX_SIMULACAO
		WHERE
      ID_SIMULACAO = $id_simulacao
      AND ANO = $AnoRef
      AND TP_GRUPO = 1
		ORDER BY
      NU_ORDEM_SITE		
		"; 
//=========================================================================================================		
// CONSULTA CONSULTA ABA RWA
		$stSqlRWA="
		SELECT 
      DE_CAPITAL, JANEIRO, FEVEREIRO, MARCO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO
		FROM
      SITE_SIMULADOR.DBO.BASVWXXX_SIMULACAO
		WHERE
      ID_SIMULACAO = $id_simulacao
      AND ANO = $AnoRef
      AND TP_GRUPO = 2
		ORDER BY
      NU_ORDEM_SITE		
		"; 
//=========================================================================================================	
// CONSULTA CONSULTA ABA INDICADORES
		$stSqlIND="
		SELECT 
      DE_CAPITAL, JANEIRO, FEVEREIRO, MARCO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO
		FROM
      SITE_SIMULADOR.DBO.BASVWXXX_SIMULACAO
		WHERE
      ID_SIMULACAO = $id_simulacao
      AND ANO = $AnoRef
      AND TP_GRUPO = 4
		ORDER BY
      NU_ORDEM_SITE		
		"; 
//=========================================================================================================	
// CONSULTA CONSULTA ABA RESULTADO
		$stSqlRES="
		SELECT 
      DE_CAPITAL, JANEIRO, FEVEREIRO, MARCO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO
		FROM
      SITE_SIMULADOR.DBO.BASVWXXX_SIMULACAO
		WHERE
      ID_SIMULACAO = $id_simulacao
      AND ANO = $AnoRef
      AND TP_GRUPO = 4
		ORDER BY
      NU_ORDEM_SITE		
		"; 
//=========================================================================================================	
// CONSULTA CONSULTA ABA CRESCIMENTO
		$stSqlCRE="
		SELECT 
      DE_CAPITAL, JANEIRO, FEVEREIRO, MARCO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO
		FROM
      SITE_SIMULADOR.DBO.BASVWXXX_SIMULACAO
		WHERE
      ID_SIMULACAO = $id_simulacao
      AND ANO = $AnoRef
      AND TP_GRUPO = 4
		ORDER BY
      NU_ORDEM_SITE		
		"; 
//=========================================================================================================	
// Este c?digo deve sair qdo as SQLs acima estiverem tratando idSimulacao = 0
if($id_simulacao==0) {
	$stSqlREF="select * from DBO.[tb_res_patrimonio_referencia_".@$AnoRef."]"; 
	$stSqlRWA="select * from DBO.[tb_res_rwa_".@$AnoRef."]";
	$stSqlRES="select * from DBO.[tb_res_resultado_".@$AnoRef."]"; 
}
	$stSqlIND="select * from DBO.[tb_res_indices_".@$AnoRef."]"; 
	$stSqlCRE="select * from DBO.[tb_crescimento_carteira_".@$AnoRef."]";
// ===============================================================================================================================================
// CONSULTA PREMISSAS 
	// descomentar a linha abaixo qdo a tabela estiver correta para receber $id_simulacao
	if($id_simulacao!=0) {
		$stSqlPRM = "select de_premissa from dbo.teste_premissa where id_simulacao = $id_simulacao";
	}
// ===============================================================================================================================================
?>
<!DOCTYPE HTML>

<html>		
<head>
	<title>Simulador de Capital</title>
	<link rel="stylesheet" type="text/css" href="../../util/sucor.css">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<!--Bibliotecas JQuery-->
	<link rel="stylesheet" href="../../js/jquery-ui.min.css">
	<script src="../../js/jquery-1.9.1.js"></script>
	<script src="../../js/jquery-ui.min.js"></script>
	<script src="../../js/jquery.ui.datepicker-pt-BR.js"></script>
	<script src="../../bibliotecas/JQuery/plugins/price_format_1_8_1_min.js"></script>
<!--Script JQuery-->
	<script>
		$(function() {
			// inclui abas
			$( "#abas" ).tabs();
//-----------------------------------------------------------------------
			//--- Ocultar linhas da tabela ----
			$('.btRecolher').click(function(){
				var nNivel = +$(this).parent().attr('nivel');
				//nNivel+=1;
				//alert(typeof(nivel));
				var $proximo = $(this).parent().nextUntil("[nivel="+ nNivel +"]","[nivel=4]");
				$(this).toggleClass('btRecolher');	
				if ($(this).attr('class')==''){
					$(this).toggleClass('btExpandir');
					$proximo.attr('visivel','false');
				}
				else {
					$(this).removeClass('btExpandir');
					$proximo.attr('visivel','');
				}	
				//alert();
			});
//----------------------------------------------------------------------------------
			//--- Campo valor mascara/valida??o ----
			$('input[name*="valor"]').priceFormat(
			{
  					prefix: 'R$ ',
  					centsSeparator: ',',
  					thousandsSeparator: '.',
  					limit: 14,
  					clearPrefix:true,
  					allowNegative: true
			});
//-----------------------------------------------------------------------
		// fim da funcao geral
		});

	</script>
<!-- Func?oes JavaScript para redirecionar a pagina --- Futuro AJAX-->
		<script language="javascript">
			function fnRedirecionar() { 
				var selectBox = document.getElementById("anoreferencia");
		 		var valor = selectBox.options[selectBox.selectedIndex].text;
				window.parent.location.href = "index.php?Ano=" + valor + "#aba-2"; 
			}
	
		</script>
</head>
<body>
		<div id="abas">
		<div id="brtitulo"><p> Plano de Capital  </p> </div>
		<div id=barraBotoes>		
		<form action="index.php">
<!--			<fieldset>-->
					<strong>ANO BASE:</strong>&nbsp;	
					<select id="anoreferencia" onchange="javascript:fnRedirecionar();">
					<option value=2013 <?php echo $AnoRef=='2013'? 'selected="selected"':'';?>>2013</option>
					<option value=2014 <?php echo $AnoRef=='2014'? 'selected="selected"':'';?>>2014</option>
					<option value=2015 <?php echo $AnoRef=='2015'? 'selected="selected"':'';?>>2015</option>
				</select>
<!--			</fieldset>-->
		</form>
		</div>
		<!--================================== Cria os botoes abas JQuery =====================================================-->	
		<table> 
				<tr>
					<td>
						<ul>
			            <li><a href="#aba-1">Par?metros</a></li>						
			            <li><a href="#aba-2">Patrim?nio Refer?ncia</a></li>
			            <li><a href="#aba-3">RWA</a></li>
			            <li><a href="#aba-4">Indicadores</a></li>
			            <li><a href="#aba-5">Resultado</a></li>
			            <li><a href="#aba-6">Crescimento da Carteira</a></li>
			        	</ul>
					</td>
				</tr>
			</table>
<!-------------------------------------------------------------------------------------------------- -->
		<div class='painel' id='aba-1'>
			<?php
				include ("FormParam.php") ;
			?>	
		</div>
		<div class='painel' id='aba-2'><table id='tbicaap'>
		<colgroup><col span="2" align="left"></colgroup>
		<thead><tr><th class='cbtbdados' colspan=14>Patrim?nio Refer?ncia <?php echo $AnoRef; ?></th></tr>
		<tr id='' class='cbtbdados' >
			<td width="100" colspan="2">Conta</td>
			<?php 
				foreach ($aMeses as $mes){
					echo '<td width="'.$tm.'">'.ucfirst(strtolower($mes)).'</td>';											
				}			
			?>
		</tr></thead>
		<tbody>
		<?php

		$cons=consultaDB_PDOodbc($stSqlREF); 
			include("corpo_tabela_exp.php");
		?>
		</tbody>
		</table></div>
		<!-- ******************************** Outra Tabela -->
		<div class='painel' id='aba-3'><table id='tbicaap'>
		<colgroup><col span="2" align="left"></colgroup>
		<thead><tr><th class='cbtbdados' colspan=14>RWA<?php echo $AnoRef; ?></th></tr>
		<tr id='' class='cbtbdados' >
			<td width="100" colspan="2">Conta</td>
						<?php 
				foreach ($aMeses as $mes){
					echo '<td width="'.$tm.'">'.ucfirst(strtolower($mes)).'</td>';											
				}			
			?>
		</tr></thead>
		<tbody>
		<?php
		$cons=consultaDB_PDOodbc($stSqlRWA); 
					include("corpo_tabela_exp.php");
		?>
		</tbody>
		</table></div>
		<!-- ******************************** Outra Tabela -->
		<div class='painel' id='aba-4'><table id='tbicaap'>
		<colgroup><col span="2" align="left"></colgroup>
		<thead><tr><th class='cbtbdados' colspan=14>Indicadores <?php echo $AnoRef; ?></th></tr>
		<tr id='' class='cbtbdados' >
			<td width="100">Conta</td>
			<td width="100">Indice</td>
			<?php 
				foreach ($aMeses as $mes){
					echo '<td width="'.$tm.'">'.ucfirst(strtolower($mes)).'</td>';											
				}			
			?>
		</tr></thead>
		<tbody>
		<?php
	
		$cons=consultaDB_PDOodbc($stSqlIND); 
		$linha=1;
		foreach ($cons as $reg=>$dado)
		{
			echo "<tr ";
			if($linha++ % 1 ==0 ) { 
				echo "class='par'";
			}
			echo ">";
			$class= "class='".substr(@$dado['DE_CAPITAL'],1,3)."'";
			foreach ($dado as $campo=>$resp){	
				if(is_numeric($resp)) {
					echo "<td $class>";
					echo number_format($resp, 2, ',', '.');
					echo $conta=='Margem (Insufici?ncia)'?'</td>':'%</td>';		
				}
				else {
						if($campo=='conta') {				
							if(@$conta!=$resp) { 
								echo '<td rowspan=2>'.$resp.'</td>';
							}
							$conta=$resp;			
						}
						else {
							echo '<td>'.$resp.'</td>';
						}
					}
			
			}
			echo "</tr>"; 
		}
		?>
		</tbody>
		</table></div>
		<!-- ******************************** Outra Tabela -->
		<div class='painel' id='aba-5'><table id='tbicaap'>
		<colgroup><col align="left"></colgroup>
		<thead><tr><th class='cbtbdados' colspan=13>Resultado <?php echo $AnoRef; ?></th></tr>
		<tr id='' class='cbtbdados' >
			<td width="100" colspan="1">Conta</td>
			<?php 
				foreach ($aMeses as $mes){
					echo '<td width="'.$tm.'">'.ucfirst(strtolower($mes)).'</td>';											
				}			
			?>
		</tr></thead>
		<tbody>
		<?php
		/* Configura??es Iniciais -- ver possibilidade de ficar em um arquivo externo */
		//$StrSql="select * from DBO.[tb_res_resultado_".@$AnoRef."]"; 
		$cons=consultaDB_PDOodbc($stSqlRES); 
		//   $cons=consultaDB_Odbc($sql); // Esta fun??o apresentou baixo desempenho para consulta 
							include("corpo_tabela.php");
/*		$linha=1;
		foreach ($cons as $reg=>$dado)
		{
			echo "<tr ";
			if($linha++ % 2 ==0 ) { 
				echo "class='par'";
			}
			echo ">";
			$class= "class='".substr(@$dado['DE_CAPITAL'],1,3)."'";			
			foreach ($dado as $campo=>$resp)
			{	
				//echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo "<td $class >";
				echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo '</td>'; 
				// money_format('%n',$resp).is_numeric($resp)?:$resp. 
			}
			echo "</tr>"; 
		}*/
		?>
		</tbody>
		</table></div>
		<!-- ******************************** Outra Tabela -->
		<div class='painel' id='aba-6'><table id='tbicaap'>
		<colgroup><col align="left"></colgroup>
		<thead><tr><th class='cbtbdados' colspan=13>Crescimento da Carteira <?php echo $AnoRef; ?></th></tr>
		<tr id='' class='cbtbdados' >
			<td width="100" colspan="1">Conta</td>
			<?php 
				foreach ($aMeses as $mes){
					echo '<td width="'.$tm.'">'.ucfirst(strtolower($mes)).'</td>';											
				}			
			?>
		</tr></thead>
		<tbody>
		<?php
		/* Configura??es Iniciais -- ver possibilidade de ficar em um arquivo externo */
		//$StrSql="select * from DBO.[tb_crescimento_carteira_".@$AnoRef."]"; 
		$cons=consultaDB_PDOodbc($stSqlCRE); 
		include("corpo_tabela.php");
		//   $cons=consultaDB_Odbc($sql); // Esta fun??o apresentou baixo desempenho para consulta 
/*		$linha=1;
		foreach ($cons as $reg=>$dado)
		{
			echo "<tr ";
			if($linha++ % 2 ==0 ) { 
				echo "class='par'";
			}
			echo ">";
			$class= "class='".substr(@$dado['DE_CAPITAL'],1,3)."'";			
			foreach ($dado as $campo=>$resp)
			{	
				echo $campo;
				//echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo "<td $class>";
				echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo '</td>'; 
				// money_format('%n',$resp).is_numeric($resp)?:$resp. 
			}
			echo "</tr>"; 
		}*/
		
		?>
		</tbody>
		</table></div>
		
		
	<div id="premissas">
		<table id='tbicaap'>
		<thead><tr><th class='cbtbdados' colspan=13> Premissas </th></tr>
		<tr>
	<?php 
		if(isset($stSqlPRM)){
			$cons=consultaDB_PDOodbc($stSqlPRM); 
			//   $cons=consultaDB_Odbc($sql); // Esta fun??o apresentou baixo desempenho para consulta 
			$linha=1;
			foreach ($cons as $reg=>$dado){
			echo "<tr ";
			if($linha++ % 2 ==0 ) { 
				echo "class='par'";
			}
			echo ">";
			
			//	$class= "class='".substr(@$dado['DE_CAPITAL'],1,3)."'";			
			foreach ($dado as $campo=>$resp)
			{	
				//echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo "<td class='N2S'>";
				echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo '</td>'; 
				// money_format('%n',$resp).is_numeric($resp)?:$resp. 
			}
				//echo "</tr>"; 
			}
		}

		?>	
		</tr>
		</table>
	</div>	
	<!--	Fecha a div de abas	-->
	</div>
<?php echo $id_simulacao; ?>
</body>
</html>