<?php
		$linha=1;
		$class="";
		$teste="fal";
		$nivel=0;
		$tagTMP=''; //  * REMOVER ESTA LINHA	- Estes controles só sçã uteis enquanto esta usando as tabelas do Estaticas DBO.[tb...
		foreach ($cons as $reg=>$dado){
			$class= "class='".substr(@$dado['DE_CAPITAL'],1,3)."'"; 
			if(isset($dado['DE_CAPITAL'])) {						//  * REMOVER ESTA LINHA	
				$nivel=substr(@$dado['DE_CAPITAL'],2,1);
			}
			else {														//  * REMOVER ESTA LINHA	
				$tagTMP='<td class="btRecolher"></td>';		//  * REMOVER ESTA LINHA	
			}			
			echo "<tr visivel=$teste nivel=$nivel ";
			if($linha++ % 2 ==0 ) { 
				echo "class='par'";
			}
			echo ">$tagTMP";
			$tagTMP='';

// ----- define a classe para as celulas da tabela - a classe vem oculta na string da consulta 'DE_CAPITAL'],1,3

			foreach ($dado as $campo=>$resp)	{	
				if($campo=='DE_CAPITAL') {
					echo $nivel<4?"<td class='btRecolher'></td>":"<td></td>";
				}
				echo "<td $class >"; 
				echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
				echo '</td>'; 
			}
			echo "</tr>"; 
			$class="";
		}
?>