<?php
/* ======================= Funçoes de Banco de Dados ============================================= */
function conectaOdbc(){	
	$userServ= 'xpto';
	$pw='xpto';
	$db='SimuladorHmp';
	$dsn = 'odbc:'.$db;   
	try { 
		$dbh = new PDO($dsn,$userServ,$pw);
	} 
	catch (PDOException $exception) { 
	  return $exception->getMessage(); 
	  exit; 
	} 	
}

function execSql_PDOodbc($sql){
	if ($conn=conectaOdbc()){
		try { 
			$stmt = $conn->prepare($sql);
	  		$stmt->execute();	
		  	return $stmt;
		}
		catch (PDOException $exception) { 
			$exception->getMessage(); 
			exit; 
		} 
	}
	else return false;	
}

function consultaDB_PDOodbc($sql){
	$result=null;
	if ($stmt=execSql_PDOodbc($sql)){
	  	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$result[]=$row;
		}
		return $result;
		unset($dbh); unset($stmt);
	}
}

function c($sql){
	$result=null;
	if ($stmt=execSql_PDOodbc($sql)){
	  	while ($row = $stmt->fetch()) {
			$result[]=$row;
		}
		return $result;
		unset($dbh); unset($stmt);
	}
}
// =======================================================================================================================
// Funççã que gera um id_simulaçao e retorna para a variavel de sessçã que será usado no select que carrega as paginas
function geraId() {
	$sql = "{CALL sp_teste_php_id}";
	$conn=conectaOdbc();
	$stmt = $conn->prepare($sql);
	$stmt->execute();
		//
	do {
	    $aId= $stmt->fetch(PDO::FETCH_ASSOC);
	} while ($stmt->nextRowset());
	//	
	$stmt->closeCursor();
	unset($stmt);
	return $aId['id_simulacao'];
	//
}
// Funççã que gera um id_simulaçao apartir do XML enviado
function geraIdXML($xml) {
	$sql = "{CALL dbo.basspXXX_teste_simulacao ('".$xml."')}";
		$conn=conectaOdbc();
		$stmt = $conn->prepare($sql);
		$stmt->execute();
				//
			do {
			    $aId= $stmt->fetch(PDO::FETCH_ASSOC);
			} while ($stmt->nextRowset());
			//	
			$stmt->closeCursor();
			unset($stmt);
			return $aId[''];//['id_simulacao'];
	//
}	
?>