<?php
		$retroceder=1;
		$mesAnt=date('m/Y',mktime (0, 0, 0, date("m")-$retroceder, date("d"),  date("Y")));
	// cria array com as datas bases que serúo usadas no combo-box	
		$tagsOpitionDatabase='<option value=""></option>';
		$formato='<option value="%04d%02d">%02d/%04d</option>'; 
		for($ano=substr($mesAnt,3,4); $ano<=2015; $ano++) {
			for($mes=1; $mes<=12;$mes++ ) {
				if(substr($mesAnt,0,2)<=$mes || substr($mesAnt,3,4)!=$ano) {	
					$tagsOpitionDatabase.=sprintf($formato, $ano, $mes, $mes, $ano);  
				}
			}
		}
		//-------------------------------
		$tagsOpitionPrazo='<option value=""></option>';		
		$formato='<option value="%02d">%02d</option>'; 
		for($mes=3; $mes<=72;$mes+=3 ) {
				$tagsOpitionPrazo.=sprintf($formato, $mes, $mes);  
		}

		$StrSql="
			SELECT 
				co_contrato, 
				vr_considerado, 
				tp_capital= 
	           case
	                 when tp_capital = 'P' then 'Cap. Principal (Adeq. BIII)'
	
	                 when tp_capital = 'C' then 'Cap. Complem. - Sem Ded. Art. 28 (Adeq. BIII)'
	
	                 when tp_capital = 'D' then 'Cap. Complem. - Com Ded. Art. 28 (ú Adeq. BIII)'
	
	                 else null
	
	            end  
			FROM 
				site_simulador.dbo.bastb006_contratos 
			WHERE
				tipo_contrato = 1
				and aa_mm_refer = (select max(aa_mm_refer) from site_simulador.dbo.bastb006_contratos)		
			";
		$consIHCD=consultaDB_PDOodbc($StrSql); 
//--------------------------------------------------- Consulta IDS --------------------------------------
		$StrSql="
			select  
			      co_contrato,
			      vr_considerado,
			      tp_capital =
			                        case
			                             when tp_capital = 'O' then 'Núvel II - Sem Ded. Art. 28 (Adeq. BIII)'
			                             when tp_capital = 'N' then 'Núvel II - Com Ded. Art. 28 (ú Adeq. BIII)'
			                             else null
			                        end  
			
			from site_simulador.dbo.bastb006_contratos
			where      tipo_contrato = 2       
			and aa_mm_refer = (select max(aa_mm_refer) from site_simulador.dbo.bastb006_contratos)
			"; 
		$consIDS=consultaDB_PDOodbc($StrSql); 
//----------------------------------------------------------------------------------------------------------		
	?>
<body>
<!-- trata_parametro.php -->
<form id="parametros" name="parametros" method="post" action="trata_parametro.php">
    <!---------------------------- DIVIDENDOS ------------------------------------> 
  <table id="tb_div" border="1">
    <thead><tr><th class='cbtbdados'  colspan="3" scope="col">DIVIDENDOS</th>
    </tr></thead>
    <?php for($i=1; $i<=5; $i++) { ?>  
    <tr>
      <td>Dividendo <?php echo $i;?></td>
      <td><label>Valor:</label>
      <input type="text" name="div<?php echo $i;?>_valor"/></td>
      <td><label>Data Base: </label>
      <select name="div<?php echo $i;?>_database"> <?php echo $tagsOpitionDatabase; ?> </select>(MM/AAAA)
    </tr>
    <?php } ?>  
  </table>
  <p>
    <!---------------------------- CAPITALIZACAO ------------------------------------>
  </p>
  <table id="tb_cap" border="1">
    <thead><tr><th class='cbtbdados'  colspan="3" scope="col">CAPITALIZAçãO</th>
    </tr></thead>
    <?php for($i=1; $i<=5; $i++) { ?>  
    <tr>
      <td>Capitalização <?php echo $i;?></td>
      <td><label>Valor:</label>
      <input type="text" name="cap<?php echo $i;?>_valor"/></td>
      <td><label>Data Base: </label>
      <select name="cap<?php echo $i;?>_database"> <?php echo $tagsOpitionDatabase; ?> </select> (MM/AAAA)
    </tr>
    <?php } ?>  
  </table>
  <p>
    <!---------------------------- IHCD ------------------------------------>
  </p>
  <table id="tb_ihcd" border="1">
    <thead><tr><th class='cbtbdados'  colspan="7" scope="col">IHCD</th>
    </tr>
    <tr><td class='cbtbdados'  colspan="7" scope="row">Contratos Vigentes</td>
    </tr></thead>
<?php $linha=1;
		foreach ($consIHCD as $reg=>$dado)
		{ ?> 
    <tr>
      <td scope="row"><label>Contrato: </label> 
      <?php echo $dado['co_contrato']; ?></td>
      <td scope="row"><label>Valor: </label> 
      <?php echo number_format($dado['vr_considerado'], 2, ',', '.'); ?> </td>
      <td scope="row"><label for="IHCD_Vige<?php echo $dado['co_contrato']; ?>_database">Data Base Enquadramento: </label>
		<select name="IHCD_Vige<?php echo $dado['co_contrato']; ?>_database"> <?php echo $tagsOpitionDatabase; ?> </select> (MM/AAAA)</td>
      <td>
       <select name="IHCD_Vige<?php echo $dado['co_contrato']; ?>_Enq" id="IHCD_Vige<?php echo $dado['co_contrato']; ?>_Enq">
        <option value='P'>Cap. Principal - Adeq. BIII</option>
        <option value='C'>Cap. Complementar - Adeq. BIII</option>
        <option value='D' selected="selected">Cap. Complementar - Núo Adeq. BIII</option>
      	</select>
      	<input name="IHCD_Vige<?php echo $dado['co_contrato']; ?>_NCto" type="hidden" value="<?php echo $dado['co_contrato']; ?>"/>
      </td>
    </tr>
<?php } ?>
<!--    -----------------------------------Contratos Novos ----------------  --> 
	</table>  
  	<table id="tb_ihcd_nv" border="1">	
    <thead><tr><td class='cbtbdados'  colspan="3"  scope="row">Contratos Novos</td>
    </tr></thead>
<?php for($i=1; $i<=5; $i++) { ?>     
    <tr>
      <td ><label for="IHCD_Novo_valor">Valor Contratado:</label>
      <input type="text" name="IHCD_Novo<?php echo $i;?>_valor" /></td>
      <td scope="row"><label for="IHCD_Novo_database">Data Base: </label>
		<select name="IHCD_Novo<?php echo $i;?>_database"> <?php echo $tagsOpitionDatabase; ?> </select> (MM/AAAA)    
      <td><label>Conta:</label><select name="IHCD_Novo<?php echo $i;?>_Enq" >
        <option></option>
        <option value='P'>Capital Principal</option>
        <option value='C'>Capital Complementar</option>
      </select></td>
    </tr>
<?php }?> 
  </table>
    <!---------------------------- IDS  ------------------------------------>  
  </p>
  <table id="tb_ids" border="1">
    <thead><tr><th class='cbtbdados'  colspan="3" scope="col">IDS - Dúvida Subordinada </th>
    </tr>
    <tr><td class='cbtbdados'  colspan="3" scope="row">Contratos Vigentes</td>
    </tr></thead>
<?php $linha=1;
		foreach ($consIDS as $reg=>$dado) 
		{ ?> 
    <tr>
      <td scope="row"><label>Contrato: </label> <?php echo $dado['co_contrato']; ?>       	
      <input name="IDS_Vige_<?php echo $dado['co_contrato']; ?>_NCto" type="hidden" value="<?php echo $dado['co_contrato']; ?>"/></td>
      <td scope="row"><label>Valor: </label> 
      <?php echo number_format($dado['vr_considerado'], 2, ',', '.'); ?>  </td>
      <td><fieldset><legend>Adequado ao BIII?</legend><table>
      		<tr>
      			<td><input type="radio" name="IDS_Vige_<?php echo $dado['co_contrato']; ?>_Enq" value="Sim">Sim</input></td>
      			<td><label>Data Base:</label><select name="IDS_Vige_<?php echo $dado['co_contrato']; ?>_database"><?php echo $tagsOpitionDatabase;?></select> </td></tr>
      		<tr>
      			<td><input type="radio" name="IDS_Vige_<?php echo $dado['co_contrato']; ?>_Enq" value="Núo" checked="checked">Núo</input></td></tr>
      </table></fieldset></td>
    </tr>
<?php } ?>    
	</table> 
<!--    --------------------Contratos Novos-------------- -->
	<table id="tb_ids_nv" border="1">  
    <thead><tr><td class='cbtbdados' colspan="6"  scope="row">Contratos Novos</td>
    </tr></thead>
<?php for($i=1; $i<=5; $i++) { ?>     
    <tr>
      <td colspan="2"><label for="IDS_Novo<?php echo $i;?>_Valor">Valor Contratado:</label>
        <input type="text" name="IDS_Novo<?php echo $i;?>_valor" /></td> 
      <td colspan="2" scope="row"><label for="IDS_Novo1_database">Data Base:</label>
        <select name="IDS_Novo<?php echo $i;?>_database"><?php echo $tagsOpitionDatabase;?></select> (MM/AAAA)</td>        
      <td>Prazo: <select name="IDS_Novo<?php echo $i;?>_prazo"><?php echo $tagsOpitionPrazo;?></select> (meses)</td>  
      </tr>
<?php } ?>       
  </table> 
<!--  ---------------------------------- Botoes ------------------------------------- -->
  <table>
		<tr>
			<td>
				<input name="acao" id="acao" type="submit" value="Simular"/> 
				<input name="cancelar" id="cancelar" type="reset" value="Cancelar"/> 		
			</td>
		</tr>  
  </table>

</form>