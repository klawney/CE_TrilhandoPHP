<?php
	$linha=1;
	foreach ($cons as $reg=>$dado)
	{
		echo "<tr ";
		if($linha++ % 2 ==0 ) { 
			echo "class='par'";
		}
		echo ">";
		foreach ($dado as $campo=>$resp)
		{	
			echo "<td >";
			echo is_numeric($resp)? number_format($resp, 2, ',', '.'):$resp;
			echo '</td>'; 
		}
		echo "</tr>"; 
	}
?>