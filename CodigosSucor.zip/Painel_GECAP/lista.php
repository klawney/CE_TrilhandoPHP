<!DOCTYPE HTML>
<html>		
<head>
	<title>Painel de Gerenciamento de Risco Corporativo </title>
	<link rel="stylesheet" type="text/css" href="/util/sucor.css">
	<link rel="stylesheet" type="text/css" href="./painel/util/painel.css">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	<!--Bibliotecas JQuery-->
	<link rel="stylesheet" href="../jquery-ui/css/jquery-ui.min.css">
	<script src="../js/jquery-1.9.1.js"></script>
	<script src="../js/jquery-ui.min.js"></script>
	<script src="../jquery-ui/i18n/jquery.ui.datepicker-pt-BR.js"></script>
	<script src="../plugins/price_format_1_8_1_min.js"></script>
	<!--arquivo de script javaScript / jQuery da pagina-->
	<script type="text/javascript" src="./painel/js/painel.js"></script>	
	<script type="text/javascript" src="./painel/js/formularios.js"></script>	

	<script type="text/javascript" src="js/painel.js"></script>
</head>
<body>
		<div id="abas">
		<div id="bt_adm"> <a  href='#adm' ><img src="../img/cadeado.jpg"/></a></div> <!--disabled='disabled' Link para a pagina administrador (verificar permissÃ£o) - onde sera possivel editar, incluir e excluir normativos  -->
		<div id="brtitulo"><p> Painel de Gerenciamento de Risco Corporativo </p>   
		
		</div>
		<!--================================== Cria os botoes abas JQuery =====================================================-->	
		<table> 
				<tr>
					<td>
						<ul>
			            <li><a href="#aba-6">Risco Corporativo</a></li>						
			            <li><a href="#aba-2">Gestão de Capital</a></li>	
			            <li><a href="#aba-1">Risco de Crédito</a></li>						
			            <li><a href="#aba-4">Risco de Mercado</a></li>						
			            <li><a href="#aba-3">Risco de Liquidez</a></li>						
			            <li><a href="#aba-5">Risco Operacional</a></li>										
<!--			            <li><a href="#aba-7">Risco Operacional p UN </a></li>						-->
			        	</ul>
					</td>
				</tr>
			</table>
<?php
//session_start();
	// start session;
		include("../includes/funcoes_gerais.inc");	
		include("../includes/funcoes_mysql.inc");	
		include("adm/manutencao.php");	
		//-----------------
		 // criar outro só com os campos abaixo
		$i=0;
//===============================================================================================================================
$colDt=array();
	if($val=aIndicesPeriodo(201101, 201307,$colDt)){
		//----------
		$strCol="";		
		$ncol=count($colDt)+6;
		// Verifica datas com dados e monta a linha de titulo dos dados 		
		foreach($colDt as $dt){ 
			$strCol.="<th>".ucfirst(substr(strtolower($aMeses[substr($dt,5,2)-1]),0,3))."/". substr($dt,2,2)."</th>";
		}	
		$a=alistaMetricas();
		$rsc=0;
		$grp="";
		//-------------------------------------------------------
		while ($dados = mysql_fetch_assoc($a)){								
			$sfx="";			
			$met=$dados['cod_metrica'];
			$dados['tipo']=='P'?$sfx=" %":$sfx="";	
			//-------------------------------------------------------
			//-------------------------------------------------------
			if($rsc!=$dados['risco']) {
				$rsc=$dados['risco'];
				if($rsc > 1) echo "</table></div>"; 
				// inicio da div aba e tabela
				?>				
				<div class='painel' id='aba-<?php echo $rsc; ?>'>
						<table id="tbdados" border="1">
							<thead>
							<tr class="cbtbdados"><th>Métrica</th><th colspan="3">Tolerância</th> <!-- <th>Tendência de 3 meses: </th> -->
							<?php echo $strCol;?>
							
							<!-- <th>Área de Monitoramento</th>--> </tr>
							</thead>
							<tbody>
				<?php	
			}	
			//-------------------------------------------------------
			if($grp!=$dados['grupo']) {
				$grp=$dados['grupo']; 
				echo "<tr class='cbtbdados' ><th colspan=".$ncol.">".$dados['grupo']."</th></tr>";
			}		
					
			$class = @$class==""?"class='par'":"";	
			//---------------------------------------------------------------
			echo "<tr $class ><td class='metrica' id='".$dados['cod_metrica']."'>".$dados['metrica']."</td>";			
//****** ???? FALTA CRIAR DB PARA TOLERANCIAS E TENDENCIA ********* 
			@$obs.="<p id='".$dados['cod_metrica']."'>".$dados['obs']."</p>";
			?>
				<td class='verde'>80</td><td class='amarelo'>80% - 100%</td><td class='vermelho'>100</td>
<!--				<td class='tendencia'>↓</td>-->
			<?php 
			//---------------------------------------------------		
			// Percorre as colunas datas validas e exibe os valores um linha
			foreach($colDt as $dt){
				if(isset($val[$met]) && array_key_exists($dt, $val[$met])) {
					echo "<td class='dados' id='".$dt.$met."' name='dados'>".$val[$met][$dt]['val'];
					echo @$sfx;
					echo "</td>";
					@$jus.="<p id='".$dt.$met."'>".$val[$met][$dt]['com']."</p>";						
				}
				else echo "<td>*</td>";	
					
			//Fim percorre as colunas datas			
			}	
			// echo "<td>".$monitores[$dados['monitor']]."</td>";
			echo "</tr>";
		// Fim while leitura dos indices consulta BD								
		}
	echo "</table></div>";
	echo "<div class='notas'><h1>Descrição da Métrica</h1> $obs </div>";
	echo "<div class='notas'><h1>Justificativa para Indice</h1> $jus </div>";
	}
?>
</div>