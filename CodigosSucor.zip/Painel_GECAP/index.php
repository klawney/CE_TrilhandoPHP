<!--------1---------2---------3---------4---------5---------6---------7---------8---------9---------0
===================================== TITULO  ============================================
<!--- Pagina  -->
<!--  -------------------------------------------------------------------------------------
===================================== REQUISITOS FUNCIONAIS ==============================
* Gerais:
- ???? 

* Especificos:
- ????;
------------------------------------------------------------------------------------------
====================================== RESPONSAVEIS ======================================
- Sob Resposabilidade de SUCOR02 - Integração de Riscos
	- C073149 =  Claudinei da Costa 	R=5197
------------------------------------------------------------------------------------------
============================== HISTORICO DE REVISOES ===================================== 
	*===============*==============*=========================================*================*
	|   Versão    	 |      Data 	 |         Alteração								 |  Responsável	|
	*===============*==============*=========================================*================*
   |   Inicial   	 |  06/05/2013	 |				NA 									 |   	C073149 		|
   |-----------------------------------------------------------------------------------------|
	|	 V-02			 |  09/05/2013	 | utilização de JQuery Abas               |		C073149		|
	*========================================================================*================*	
------------------------------------------------------------------------------------------
=========================  INICIO CÓDIGO  ==============================================-->

<!--
----------------------------------------------------------------------------------------
-->
<!DOCTYPE HTML>
<html>		
<head>
	<title>Painel de Gerenciamento de Risco Corporativo </title>
	<link rel="stylesheet" type="text/css" href="/util/sucor.css">
	<link rel="stylesheet" type="text/css" href="./painel/util/painel.css">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	<!--Bibliotecas JQuery-->
	<link rel="stylesheet" href="../js/jquery-ui.min.css">
	<script src="../js/jquery-1.9.1.js"></script>
	<script src="../js/jquery-ui.min.js"></script>
	<script src="../js/jquery.ui.datepicker-pt-BR.js"></script>
	<script src="../plugins/price_format_1_8_1_min.js"></script>
	<!--arquivo de script javaScript / jQuery da pagina-->
	<script type="text/javascript" src="../painel/js/painel.js"></script>	

</head>
<body>
		<div id="abas">
		<div id="bt_adm"> <a  href='#adm' ><img src="../img/cadeado.jpg"/></a></div> <!--disabled='disabled' Link para a pagina administrador (verificar permissÃ£o) - onde sera possivel editar, incluir e excluir normativos  -->
		<div id="brtitulo"><p> Painel de Gerenciamento de Risco Corporativo </p>   
		
		</div>
		<!--================================== Cria os botoes abas JQuery =====================================================-->	
		<table> 
				<tr>
					<td>
						<ul>
			            <li><a href="#aba-1">Risco Corporativo</a></li>						
			            <li><a href="#aba-2">Gestão de Capital</a></li>	
			            <li><a href="#aba-3">Risco de Crédito</a></li>						
			            <li><a href="#aba-4">Risco de Mercado</a></li>						
			            <li><a href="#aba-5">Risco de Liquidez</a></li>						
			            <li><a href="#aba-6">Risco Operacional</a></li>										
<!--			            <li><a href="#aba-7">Risco Operacional p UN </a></li>						-->
			        	</ul>
					</td>
				</tr>
			</table>
<!-------------------------------------------------------------------------------------------------- -->
		<div class='painel' id='aba-1'>
			<?php
				include ("corporativo.php") ;
			?>	
		</div>
		<div class='painel' id='aba-2'>
			<?php
				 include ("capital.php") ;
			?>	
		</div>	
		<div class='painel' id='aba-3'>
			<?php
				include ("credito.php") ;
			?>	
		</div>
		<div class='painel' id='aba-4'>
			<?php
				include ("mercado.php") ;
			?>	
		</div>
		<div class='painel' id='aba-5'>
			<?php
				include ("liquidez.php") ;
			?>	
		</div>
		<div class='painel' id='aba-6'>
			<?php
				include ("operacional.php") ;
			?>	
		</div>		
		<div class='painel' id='aba-7'>
			<?php
			// por hora esta suspenso 
//				 include ("operacional_un.php") ;
//				 include ("operacional_ung.php") ;
//				 include ("operacional_ung1.php") ;
			?>	
		</div>		
	<!--	Fecha a div de abas	-->
	</div>
	<div>
		<iframe id="adm" src="./painel/adm/index.php"> 
		</iframe>
	</div>
	<?php
		include ("legenda.php") ;
	?>	
</body>
</html>