		$(function() {
			// inclui abas
			$( "#abas" ).tabs();
//----------------------------Variáveis Gerais de Elementos da Pagina-------------
			//			
			var $tolerancias = $('.verde, .amarelo, .vermelho');
			var $dados = $('td[name*="dado"]');		
			var $tendencia = $('td.tendencia');		
			var $objMostramLegenda = $('td.tendencia, td[name*="dado"], .verde, .amarelo, .vermelho');			
			// 
			var texto = "";		
			var scrImg="";
			
//---------- Troca a classe / imagem  de   T E N D E N C I A  ---------------	
//		
			$tendencia.each(function(i){					
				cod = $(this).text().charCodeAt(0);
				switch(cod) {
					case 8593:{
						//classe="tend_acima";
						srcImg = "../../img/seta_acima.png";
					}
					break;
					case 8595:{
						//classe="tend_abaixo";
						srcImg = "../../img/seta_abaixo.png";
					}
					break;
					case 8596:{
						//classe="tend_mantem";
						srcImg = "../../img/seta_dupla.png";
					}
					break;						
					default:{
//						classe="tendencia";
						srcImg ="";
					}					
				}		
				// Remove o texto da celula 
				$(this).text(" ");
				// ----- Adicionar uma imagem ----		
				if(srcImg !=""){ 
					$("<img src='" + srcImg + "'/>").appendTo(this);			
				} 

			});
//==================================================================================

//------------- D I A L O G O S ---------------------------------------------------
//  ---- Mostra a pagina adm em um dialogo 
	$('.notas').dialog({ 
		autoOpen: false,
		width: 550	
	});
//---------------------------------------
	$('#adm').dialog({ 
		autoOpen: false,
		title: "Area Administração",
		width: 1000 , 
		height:400,
		open: function() {  $('#abas').css('opacity',0.2).css('pointer-events','none');}, //click(function(e){ e.preventDefault(); });  },		
		close: function() {  $('#abas').css('opacity',1).css('pointer-events','auto');  }					
	});
// --- Mostra a legenda por 5 segundos
	$('#legenda').dialog({ 
		title: function() { 					
			return $('#legenda').children("h1").hide().text();	
		},
		width: 550					
	});
	setTimeout(function(){$('#legenda').dialog("close");},5000);		
// ------------					
// --- Mostra a legenda quando clicar sobre os itens
	$($objMostramLegenda).click( function () {
		$('#legenda').dialog("open");
	});
//---------------------------------------------------------------------------------
	$('#bt_adm').click( function () {
		$('#adm').dialog("open");	
	});
	// Desabilita o link para a div adm, para funcionar apenas a opção botao via jQuery
	$('#bt_adm a').hide();
// --------------------------------------------------------------------------------			
// ------------------ N O T A S ---------------------------------------------------
// --- Mostra o diálogo Notas quando clicar sobre a metrica
			$('.metrica').click( function () {	
				$divNotas=$('.notas');
				// oculta todo o conteudo para mostrar apenas a linha que corresponda ao ID desejado
				$divNotas.children().hide();			
				// pega o id de metrica que sera o obsid da nota 
				nota="#" + $(this).attr('id');
				// Seleciona a Div que contem a nota selecionada para a variavel $Nota e aplica estilo			
				$Nota=$divNotas.children(nota).parent().css({"border":"2px solid green", "min-width":"520px"});
				// abre o dialogo Notas / Seta o Titulo e exibe o conteudo que esta contido no elemento p até o proximo p
				$Nota.dialog( 
						"option", 
						"title", 
						$($Nota).children("h1").hide().text()
					).dialog("open").children(nota).show().nextUntil('p').show();
			});
// --- Mostra o diálogo Notas quando clicar sobre a metrica
			$('.dados').click( function () {	
				$divNotas=$('.notas');
				// oculta todo o conteudo para mostrar apenas a linha que corresponda ao ID desejado
				$divNotas.children().hide();			
				// pega o id de metrica que sera o obsid da nota 
				nota="#" + $(this).attr('id');
				// Seleciona a Div que contem a nota selecionada para a variavel $Nota e aplica estilo			
				$Nota=$divNotas.children(nota).parent().css({"border":"2px solid green", "min-width":"520px"});
				// abre o dialogo Notas / Seta o Titulo e exibe o conteudo que esta contido no elemento p até o proximo p
				$Nota.dialog( 
						"option", 
						"title", 
						$($Nota).children("h1").hide().text()
					).dialog("open").children(nota).show().nextUntil('p').show();
			});
// --- Mostra o diálogo Notas quando clicar no botão Informação

			$('.bt_informa').click( function () {	
				// oculta todo o conteudo para mostrar apenas a linha que corresponda ao ID desejado
				$('.notas').children().hide();
				nota="#" + $(this).attr('alt');
				//alert($divnota.attr("class"));
				$Nota=$('.notas').children(nota).parent().css("border","2px solid green");
					$Nota.dialog( 
						"option", 
						"title", 
						$($Nota).children("h1").hide().text()
					).dialog("open").children(nota).show().nextUntil('p').show();
					
			});
			
				
				$(document).tooltip({track: true});
				
			//--- tooltips sobre os dados --- 	
						
				$($dados).tooltip({
					items: $dados,
					content:function() { 
						texto = "valor = " + $(this).text() + '<br>';
						texto += "verde = " + $(this).parent().children(".verde").text() + '<br>';
						texto += "vermelho = " + $(this).parent().children(".vermelho").text();
						//var filho = linha
						//alert();
						return texto;					
					}
				});
				
			//--- tooltips sobre os Tolerancias e Tendencia --- 	
						
				$($tolerancias).tooltip({
					items: $tolerancias,
					track: true,
					content:"Clique para ver legenda"
				});
			
			//--- tooltips sobre botao de informações --- 	
						
				$('.bt_informa').tooltip({
					items: '.bt_informa',
					content:"Informações complementares"
				});
			
//-----------------------------------------------------------------------
//--------------- altera a classe conforme tolerancia -------------------
		//var $dados = $('td[name*="dado"]');
		var valorCel, statusCell, tolVerde, tolVermelha, maiorEh, menorEh;
//
		var tolMaxima = 0;
		var tolMinima = 0;
		var msg = "";
//		
		$dados.each(function(i){
			valorCel = 0;
			tolVerde = 0;
			tolVermelha = 0;
	//		
			maiorEh = "";
			menorEh = "";
			statusCell = "cinza";
			// captura os valores tolerancia 
			tolVerde= + $(this).parent().children(".verde").text().replace(/,/g,".");			
			tolVermelha= + $(this).parent().children(".vermelho").text().replace(/,/g,".");	
			// captura o valor da celula e tenta tranformalo em número 
			valorCel= + $(this).text().replace(/,/g,".");
			// Verifica se são números 		
			if (($.isNumeric(tolVerde) && $.isNumeric(valorCel)) && ($.isNumeric(tolVermelha))) { 
				// Verifica quem é max e quem é mim 
				if (tolVerde < tolVermelha) {
					crescente=true;
				}
				else if(tolVerde > tolVermelha)  {
						crescente=false;
				}
					else {
						crescente=null;
				}
				//msg+="<-"+ tolVerde + tolVermelha + "Menor é " + menorEh + "-> \n";
				
					// SE for menor que vermelho quando Decrescente , OU se for Maior que vermelho qdo Crescente  
				if ((!crescente && (valorCel < tolVermelha)) || (crescente && (valorCel > tolVermelha)) ) {  
					statusCell="critico";
				}
				else if (  (!crescente && valorCel > tolVerde) || (crescente && valorCel < tolVerde) ) { 
						statusCell="desejavel";	
					}
					else if (crescente!=null){
						statusCell="toleravel";	
				}
			
			//-------------------------------
				$(this).removeClass();
				$(this).addClass(statusCell);
			} 
			else {
				$(this).removeClass();
				$(this).addClass("cinza");
			}
			if ($.isNumeric(valorCel) && valorCel!=0 ) { 
				//$(this).text(valorCel + " %");  
			}
		// fim each em $dados
      }); 	
			
  
//-----------------------------------------------------------------------
		// fim da funcao geral
		});
